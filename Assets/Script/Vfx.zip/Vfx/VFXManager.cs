using UnityEngine;

public class VFXManager : MonoBehaviour
{
    [SerializeField]
    private GameObject RingMarker;
    [SerializeField]
    private GameObject[] magicVFX;
    public GameObject[] MagicVFX { get { return magicVFX; } }
    [SerializeField]
    private MagicData[] magicData;
    public MagicData[] MagicData { get { return magicData; } }
    public GameObject Marker { get { return RingMarker; } }
    public static VFXManager Instance;

     void Awake()
    {
        Instance = this;
    }
    void Start()
    {
        
    }

    public void LoadMagic(int id, Vector3 posA, float time)
    {
        if (magicVFX[id] == null) return;
        GameObject objload = Instantiate(magicVFX[id], posA, Quaternion.identity);
        Destroy(objload,time);
    }
    public void ShootMagic(int id, Vector3 posA, Vector3 posB, float time)
    {
        if (magicVFX[id] == null) return;
        GameObject objShoot = Instantiate(magicVFX[id],posA, Quaternion.identity);
        objShoot.transform.position = Vector3.LerpUnclamped(posA, posB, time);
        Destroy(objShoot,time);
    }
}
